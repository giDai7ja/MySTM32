#include "stm32f10x.h"                  // Device header




int main(void){
	return 0;
	}
